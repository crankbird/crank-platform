from __future__ import annotations
from typing import cast
from fastapi import Request
from ..typing_interfaces import (
    PlatformServiceProtocol,
    ProtocolServiceProtocol,
    DiscoveryServiceProtocol,
)

def get_platform(request: Request) -> PlatformServiceProtocol:
    svc = getattr(request.app.state, "platform", None)
    if svc is None:
        raise RuntimeError("PlatformService not initialized")
    return cast(PlatformServiceProtocol, svc)

def get_protocol(request: Request) -> ProtocolServiceProtocol:
    svc = getattr(request.app.state, "protocol_service", None)
    if svc is None:
        raise RuntimeError("ProtocolService not initialized")
    return cast(ProtocolServiceProtocol, svc)

def get_discovery(request: Request) -> DiscoveryServiceProtocol:
    svc = getattr(request.app.state, "discovery_service", None)
    if svc is None:
        raise RuntimeError("DiscoveryService not initialized")
    return cast(DiscoveryServiceProtocol, svc)
